import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { clearBillingUiStorage } from '../utils/billingUi';
import {
  clearStoredAccessToken,
  clearStoredRefreshToken,
  persistAccessToken,
  persistRefreshToken,
  readStoredAccessToken,
  readStoredRefreshToken,
  rememberCompanyId,
  setAccessTokenInMemory,
} from '../utils/authSession';
import { decodeJwtPayload } from '../utils/jwtClient';
import { useProviderDebug } from '../utils/providerDebug';
import { authApi, ensureAccessTokenReady, LoginDeviceVerificationRequiredError } from '../services/api';
import i18n from '../i18n';
import { getBaseLanguage } from '../utils/i18nLocale';
import { persistLanguageCode } from '../utils/i18nPersist';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: string;
  branchRole?: 'SUPER_ADMIN' | 'BRANCH_ADMIN' | 'BRANCH_USER';
  companyId?: string;
  branchId?: string;
  branch?: string;
  /** RBAC codes from backend (login or GET /auth/me). */
  permissions?: string[];
  /** Persisted UI language (en | zh | ar | ur). */
  language?: string;
  direction?: 'ltr' | 'rtl';
  /** Preferred view currency (ISO 4217). */
  currency?: string;
  branchDefaultLanguage?: string;
  branchDefaultCurrency?: string;
  /** When true, login always triggers step-up OTP. */
  twoFactorEnabled?: boolean;
  /** Preferred step-up channel from profile (email | sms | whatsapp). */
  otpChannel?: string;
}

function applyLocaleFromSessionUser(u: AuthUser) {
  if (u.language) {
    const base = getBaseLanguage(u.language);
    void i18n.changeLanguage(base);
    persistLanguageCode(base);
  }
  if (u.currency) {
    try {
      localStorage.setItem('fusiku_view_currency', String(u.currency).trim().toUpperCase());
    } catch {
      /* ignore */
    }
  }
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  loading: boolean;
  login: (
    email: string,
    password: string,
    opts?: { companyId?: string | null; stepUpChannel?: 'EMAIL' | 'SMS' | 'WHATSAPP' }
  ) => Promise<void>;
  setSession: (token: string, user: AuthUser, refreshToken?: string | null) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  useProviderDebug('AuthProvider');
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    void (async () => {
      await ensureAccessTokenReady();
      const t = readStoredAccessToken();
      const rt = readStoredRefreshToken();
      const u = localStorage.getItem('user');

      if (t && u) {
        try {
          if (!cancelled) setToken(t);
          const parsed = JSON.parse(u) as AuthUser;

          const p = decodeJwtPayload(t);
          const branchRole =
            p?.branchRole === 'SUPER_ADMIN' ||
            p?.branchRole === 'BRANCH_ADMIN' ||
            p?.branchRole === 'BRANCH_USER'
              ? p.branchRole
              : undefined;

          let next = branchRole ? { ...parsed, branchRole } : parsed;
          if (!Array.isArray(next.permissions) || next.permissions.length === 0) {
            try {
              const { data } = await authApi.me();
              const me = data as AuthUser;
              if (me?.id) {
                next = branchRole ? { ...me, branchRole } : me;
                applyLocaleFromSessionUser(next);
                localStorage.setItem('user', JSON.stringify(next));
              }
            } catch {
              /* offline or legacy; keep user without permissions */
            }
          }
          if (!cancelled) {
            applyLocaleFromSessionUser(next);
            setUser(next);
          }
        } catch {
          clearStoredAccessToken();
          clearStoredRefreshToken();
          localStorage.removeItem('user');
        }
      } else if (rt && u) {
        try {
          const parsed = JSON.parse(u) as AuthUser;
          const primed = await ensureAccessTokenReady();
          const access = readStoredAccessToken();
          if (!cancelled) {
            applyLocaleFromSessionUser(parsed);
            setUser(parsed);
            if (primed && access) setToken(access);
          }
        } catch {
          clearStoredRefreshToken();
          localStorage.removeItem('user');
        }
      }

      if (!cancelled) setLoading(false);
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const login = async (
    email: string,
    password: string,
    opts?: { companyId?: string | null; stepUpChannel?: 'EMAIL' | 'SMS' | 'WHATSAPP' }
  ) => {
    try {
      const { data } = await authApi.login(email, password, opts?.companyId, {
        stepUpChannel: opts?.stepUpChannel,
      });
      if (!data || typeof data !== 'object') throw new Error('Invalid login response');

      if (
        'requiresDeviceVerification' in data &&
        data.requiresDeviceVerification &&
        typeof (data as { challengeId?: unknown }).challengeId === 'string'
      ) {
        const d = data as {
          challengeId: string;
          availableChannels?: string[];
          defaultChannel?: string;
        };
        throw new LoginDeviceVerificationRequiredError(d.challengeId, {
          availableChannels: d.availableChannels,
          defaultChannel: d.defaultChannel,
        });
      }

      const sessionToken = String(data.accessToken ?? data.token ?? '').trim();
      const refreshToken = String(data.refreshToken ?? '').trim();

      if (!sessionToken) throw new Error('No token');

      persistAccessToken(sessionToken);
      if (refreshToken) persistRefreshToken(refreshToken);
      try {
        localStorage.setItem('token', sessionToken);
      } catch {
        /* ignore */
      }

      const p = decodeJwtPayload(sessionToken);
      const branchRole =
        p?.branchRole === 'SUPER_ADMIN' ||
        p?.branchRole === 'BRANCH_ADMIN' ||
        p?.branchRole === 'BRANCH_USER'
          ? p.branchRole
          : undefined;

      const rawUser = data.user as AuthUser | undefined;
      if (!rawUser?.id) throw new Error('Invalid login response: missing user');

      const nextUser = branchRole ? { ...rawUser, branchRole } : rawUser;

      applyLocaleFromSessionUser(nextUser);
      try {
        localStorage.setItem('user', JSON.stringify(nextUser));
      } catch {
        /* ignore */
      }
      rememberCompanyId(nextUser.companyId);

      setToken(sessionToken);
      setUser(nextUser);
    } catch (err) {
      console.error('[AuthProvider] login', err);
      throw err;
    }
  };

  const setSession = (token: string, user: AuthUser, refreshToken?: string | null) => {
    const safeToken = String(token ?? '').trim();
    if (!safeToken || !user || typeof user !== 'object' || !user.id) {
      console.error('[AuthProvider] setSession: invalid token or user');
      return;
    }

    persistAccessToken(safeToken);
    const rt = String(refreshToken ?? '').trim();
    if (rt) persistRefreshToken(rt);

    const p = decodeJwtPayload(safeToken);
    const branchRole =
      user.branchRole ||
      (p?.branchRole === 'SUPER_ADMIN' ||
      p?.branchRole === 'BRANCH_ADMIN' ||
      p?.branchRole === 'BRANCH_USER'
        ? p.branchRole
        : undefined);

    const u = branchRole ? { ...user, branchRole } : user;

    applyLocaleFromSessionUser(u);
    localStorage.setItem('user', JSON.stringify(u));
    rememberCompanyId(user.companyId);

    setToken(safeToken);
    setUser(u);
  };

  const logout = () => {
    clearStoredAccessToken();
    clearStoredRefreshToken();
    setAccessTokenInMemory(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    clearBillingUiStorage();

    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, setSession, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}